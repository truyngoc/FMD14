using System;
using System.IO;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace OsqlScript
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class GenerateOsql : System.Windows.Forms.Form
	{
		private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
		private System.Windows.Forms.TextBox txtFolder;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnSelectFolder;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtBatchScript;
		private System.Windows.Forms.Button btnSelectBatchScript;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;
		private System.Windows.Forms.Button btnGenerate;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox txtReportFile;
		private System.Windows.Forms.CheckBox chkSecurity;
		private System.Windows.Forms.CheckBox chkReport;
		private System.Windows.Forms.TextBox txtPassword;
		private System.Windows.Forms.TextBox txtUsername;
		private System.Windows.Forms.TextBox txtDatabase;
		private System.Windows.Forms.TextBox txtServer;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.RadioButton rbtnAlphabetically;
		private System.Windows.Forms.RadioButton rbtnDateCreated;
		private System.Windows.Forms.RadioButton rbtnDateModified;
		private System.Windows.Forms.RadioButton rbtnFileNameDate;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public GenerateOsql()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
			this.txtFolder = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.btnSelectFolder = new System.Windows.Forms.Button();
			this.label2 = new System.Windows.Forms.Label();
			this.txtBatchScript = new System.Windows.Forms.TextBox();
			this.btnSelectBatchScript = new System.Windows.Forms.Button();
			this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
			this.btnGenerate = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.chkSecurity = new System.Windows.Forms.CheckBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.chkReport = new System.Windows.Forms.CheckBox();
			this.label7 = new System.Windows.Forms.Label();
			this.txtReportFile = new System.Windows.Forms.TextBox();
			this.txtPassword = new System.Windows.Forms.TextBox();
			this.txtUsername = new System.Windows.Forms.TextBox();
			this.txtDatabase = new System.Windows.Forms.TextBox();
			this.txtServer = new System.Windows.Forms.TextBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.rbtnAlphabetically = new System.Windows.Forms.RadioButton();
			this.rbtnDateCreated = new System.Windows.Forms.RadioButton();
			this.rbtnDateModified = new System.Windows.Forms.RadioButton();
			this.rbtnFileNameDate = new System.Windows.Forms.RadioButton();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// txtFolder
			// 
			this.txtFolder.Location = new System.Drawing.Point(104, 24);
			this.txtFolder.Name = "txtFolder";
			this.txtFolder.ReadOnly = true;
			this.txtFolder.Size = new System.Drawing.Size(152, 20);
			this.txtFolder.TabIndex = 1;
			this.txtFolder.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 24);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(72, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "Scan Folder";
			// 
			// btnSelectFolder
			// 
			this.btnSelectFolder.Location = new System.Drawing.Point(264, 24);
			this.btnSelectFolder.Name = "btnSelectFolder";
			this.btnSelectFolder.Size = new System.Drawing.Size(24, 23);
			this.btnSelectFolder.TabIndex = 2;
			this.btnSelectFolder.Text = "...";
			this.btnSelectFolder.Click += new System.EventHandler(this.btnSelectFolder_Click);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(16, 56);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(72, 23);
			this.label2.TabIndex = 3;
			this.label2.Text = "Batch Script";
			// 
			// txtBatchScript
			// 
			this.txtBatchScript.Location = new System.Drawing.Point(104, 56);
			this.txtBatchScript.Name = "txtBatchScript";
			this.txtBatchScript.ReadOnly = true;
			this.txtBatchScript.Size = new System.Drawing.Size(152, 20);
			this.txtBatchScript.TabIndex = 4;
			this.txtBatchScript.Text = "";
			// 
			// btnSelectBatchScript
			// 
			this.btnSelectBatchScript.Location = new System.Drawing.Point(264, 56);
			this.btnSelectBatchScript.Name = "btnSelectBatchScript";
			this.btnSelectBatchScript.Size = new System.Drawing.Size(24, 23);
			this.btnSelectBatchScript.TabIndex = 5;
			this.btnSelectBatchScript.Text = "...";
			this.btnSelectBatchScript.Click += new System.EventHandler(this.btnSelectBatchScript_Click);
			// 
			// saveFileDialog1
			// 
			this.saveFileDialog1.DefaultExt = "bat";
			this.saveFileDialog1.Filter = "Batch files (*.bat)|*.bat";
			// 
			// btnGenerate
			// 
			this.btnGenerate.Location = new System.Drawing.Point(279, 272);
			this.btnGenerate.Name = "btnGenerate";
			this.btnGenerate.TabIndex = 18;
			this.btnGenerate.Text = "Generate";
			this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 88);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(64, 23);
			this.label3.TabIndex = 6;
			this.label3.Text = "Server";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(16, 120);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(64, 23);
			this.label4.TabIndex = 8;
			this.label4.Text = "Database";
			// 
			// chkSecurity
			// 
			this.chkSecurity.Location = new System.Drawing.Point(16, 160);
			this.chkSecurity.Name = "chkSecurity";
			this.chkSecurity.Size = new System.Drawing.Size(184, 24);
			this.chkSecurity.TabIndex = 10;
			this.chkSecurity.Text = "Use Integrated Security";
			this.chkSecurity.CheckedChanged += new System.EventHandler(this.chkSecurity_CheckedChanged);
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(16, 200);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(56, 23);
			this.label5.TabIndex = 11;
			this.label5.Text = "Username";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(16, 232);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(64, 23);
			this.label6.TabIndex = 13;
			this.label6.Text = "Password";
			// 
			// chkReport
			// 
			this.chkReport.Location = new System.Drawing.Point(328, 24);
			this.chkReport.Name = "chkReport";
			this.chkReport.Size = new System.Drawing.Size(152, 24);
			this.chkReport.TabIndex = 15;
			this.chkReport.Text = "Use Report Output File";
			this.chkReport.CheckedChanged += new System.EventHandler(this.chkReport_CheckedChanged);
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(328, 64);
			this.label7.Name = "label7";
			this.label7.TabIndex = 16;
			this.label7.Text = "Report Output File";
			// 
			// txtReportFile
			// 
			this.txtReportFile.Enabled = false;
			this.txtReportFile.Location = new System.Drawing.Point(448, 64);
			this.txtReportFile.Name = "txtReportFile";
			this.txtReportFile.Size = new System.Drawing.Size(152, 20);
			this.txtReportFile.TabIndex = 17;
			this.txtReportFile.Text = "Report.txt";
			// 
			// txtPassword
			// 
			this.txtPassword.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.txtPassword.Location = new System.Drawing.Point(104, 232);
			this.txtPassword.Name = "txtPassword";
			this.txtPassword.PasswordChar = '*';
			this.txtPassword.Size = new System.Drawing.Size(184, 20);
			this.txtPassword.TabIndex = 14;
			this.txtPassword.Text = "";
			// 
			// txtUsername
			// 
			this.txtUsername.Location = new System.Drawing.Point(104, 200);
			this.txtUsername.Name = "txtUsername";
			this.txtUsername.Size = new System.Drawing.Size(184, 20);
			this.txtUsername.TabIndex = 12;
			this.txtUsername.Text = "";
			// 
			// txtDatabase
			// 
			this.txtDatabase.Location = new System.Drawing.Point(104, 120);
			this.txtDatabase.Name = "txtDatabase";
			this.txtDatabase.Size = new System.Drawing.Size(184, 20);
			this.txtDatabase.TabIndex = 9;
			this.txtDatabase.Text = "";
			// 
			// txtServer
			// 
			this.txtServer.Location = new System.Drawing.Point(104, 88);
			this.txtServer.Name = "txtServer";
			this.txtServer.Size = new System.Drawing.Size(184, 20);
			this.txtServer.TabIndex = 7;
			this.txtServer.Text = "";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.rbtnFileNameDate);
			this.groupBox1.Controls.Add(this.rbtnDateModified);
			this.groupBox1.Controls.Add(this.rbtnDateCreated);
			this.groupBox1.Controls.Add(this.rbtnAlphabetically);
			this.groupBox1.Location = new System.Drawing.Point(328, 112);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(280, 144);
			this.groupBox1.TabIndex = 19;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Sorting Method";
			// 
			// rbtnAlphabetically
			// 
			this.rbtnAlphabetically.Checked = true;
			this.rbtnAlphabetically.Location = new System.Drawing.Point(16, 24);
			this.rbtnAlphabetically.Name = "rbtnAlphabetically";
			this.rbtnAlphabetically.TabIndex = 0;
			this.rbtnAlphabetically.TabStop = true;
			this.rbtnAlphabetically.Text = "Alphabetically";
			// 
			// rbtnDateCreated
			// 
			this.rbtnDateCreated.Location = new System.Drawing.Point(160, 24);
			this.rbtnDateCreated.Name = "rbtnDateCreated";
			this.rbtnDateCreated.TabIndex = 1;
			this.rbtnDateCreated.Text = "Date Created";
			// 
			// rbtnDateModified
			// 
			this.rbtnDateModified.Location = new System.Drawing.Point(16, 56);
			this.rbtnDateModified.Name = "rbtnDateModified";
			this.rbtnDateModified.TabIndex = 2;
			this.rbtnDateModified.Text = "Date Modified";
			// 
			// rbtnFileNameDate
			// 
			this.rbtnFileNameDate.Location = new System.Drawing.Point(160, 56);
			this.rbtnFileNameDate.Name = "rbtnFileNameDate";
			this.rbtnFileNameDate.TabIndex = 3;
			this.rbtnFileNameDate.Text = "File Name Date";
			// 
			// GenerateOsql
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(632, 302);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.txtServer);
			this.Controls.Add(this.txtDatabase);
			this.Controls.Add(this.txtUsername);
			this.Controls.Add(this.txtPassword);
			this.Controls.Add(this.txtReportFile);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.chkReport);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.chkSecurity);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.btnGenerate);
			this.Controls.Add(this.btnSelectBatchScript);
			this.Controls.Add(this.txtBatchScript);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.btnSelectFolder);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtFolder);
			this.Name = "GenerateOsql";
			this.Text = "Generate osql Batch Script";
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new GenerateOsql());
		}

		private void btnSelectFolder_Click(object sender, System.EventArgs e)
		{
			DialogResult result = folderBrowserDialog1.ShowDialog();
			if(result == DialogResult.OK) 
			{
				this.txtFolder.Text = folderBrowserDialog1.SelectedPath;
			}
		}

		private void btnSelectBatchScript_Click(object sender, System.EventArgs e)
		{
			if (this.txtFolder.Text != "")
				this.saveFileDialog1.InitialDirectory = this.txtFolder.Text;
			
			DialogResult result = saveFileDialog1.ShowDialog();
			if(result == DialogResult.OK) 
			{
				this.txtBatchScript.Text = saveFileDialog1.FileName;
			}
		}

		private void btnGenerate_Click(object sender, System.EventArgs e)
		{
			OsqlScript script = new OsqlScript(this.txtFolder.Text,
				Path.GetFileNameWithoutExtension(this.txtBatchScript.Text));
			script.Server = this.txtServer.Text;
			script.Database = this.txtDatabase.Text;
			script.UseIntegratedSecurity = this.chkSecurity.Checked;
			script.UserName = this.txtUsername.Text;
			script.Password=this.txtPassword.Text;
			script.UseReportFile = this.chkReport.Checked;
			script.ReportFile=this.txtReportFile.Text;
			if (this.rbtnAlphabetically.Checked) 
				script.SortStrategy = SortStrategy.Alphabetical;
			else if (this.rbtnDateCreated.Checked)
				script.SortStrategy = SortStrategy.DateCreated;
			else if (this.rbtnDateModified.Checked)
				script.SortStrategy = SortStrategy.DateModified;
			else if (this.rbtnFileNameDate.Checked)
				script.SortStrategy = SortStrategy.FileNameDate;
			script.Generate();
			MessageBox.Show(script.BatchFileName + " successfully generated.");
			btnGenerate.BackColor = Color.Moccasin;
		}


		private void chkSecurity_CheckedChanged(object sender, System.EventArgs e)
		{
				this.txtUsername.Enabled = !this.chkSecurity.Checked;
				this.txtPassword.Enabled = !this.chkSecurity.Checked;
		}

		private void chkReport_CheckedChanged(object sender, System.EventArgs e)
		{
			this.txtReportFile.Enabled = this.chkReport.Checked; 
		}
	}
}
