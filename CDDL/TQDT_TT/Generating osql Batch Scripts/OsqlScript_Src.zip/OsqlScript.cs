using System;
using System.IO;
using System.Text;
using System.Collections;

namespace OsqlScript
{
	/// <summary>
	/// Generates an OSql batch script using all the .sql files in a specified folder.
	/// </summary>
	public class OsqlScript
	{

		#region Fields & Properties

		private string folder;
		/// <summary>
		/// The Full Path of the Folder to scan.
		/// </summary>
		public string Folder
		{
			get{return this.folder;}
			set
			{
				if (!Directory.Exists(value))
					throw new DirectoryNotFoundException("This directory does not exist");
				else
					this.folder = value;
			}
		}

		
		private string batchFileName;
		/// <summary>
		/// The Name of the batch script to be created or appended, without an extension
		/// </summary>
		public string BatchFileName
		{
			get{return this.batchFileName;}
			set{this.batchFileName = value + ".bat";}
		}	
	


		private string server;
		/// <summary>
		/// The Server to connect to
		/// </summary>
		public string Server
		{
			get{return this.server;}
			set{this.server = value;} 
		}


		private string database;
		/// <summary>
		/// The Database to connect to
		/// </summary>		
		public string Database
		{
			get{return this.database;}
			set{this.database = value;} 
		}


		private string userName;
		/// <summary>
		/// The Username to use
		/// </summary>
		public string UserName
		{
			get{return this.userName;}
			set{this.userName = value;}
		}


		private string password;
		/// <summary>
		/// The Password to use
		/// </summary>
		public string Password
		{
			get{return this.password;}
			set{this.password = value;}
		}


		private bool useIntegratedSecurity;
		/// <summary>
		/// Specifies whether integrated security is used
		/// </summary>
		public bool UseIntegratedSecurity
		{
			get{return this.useIntegratedSecurity;}
			set{this.useIntegratedSecurity = value;}
		}


		private bool useReportFile;
		/// <summary>
		/// Specifies whether an Report output file will be used
		/// </summary>
		public bool UseReportFile
		{
			get{return this.useReportFile;}
			set{this.useReportFile = value;}
		}
		

		private string reportFile;
		/// <summary>
		/// The Name of the report output file 
		/// </summary>
		public string ReportFile
		{
			get{return this.reportFile;}
			set{this.reportFile = value;}
		}


		private FileInfo[] files;
		/// <summary>
		/// The collection of files scanned - Read Only
		/// </summary>
		public FileInfo[] Files
		{
			get 
			{
				if (this.files == null)
					return (this.files = new FileInfo[]{});
				else
					return this.files;
			}			
			set
			{
				this.files=value;
				this.folderScanned = false;
			}
		}		

		private bool folderScanned;
		/// <summary>
		/// Indicates that the folder has been scanned and the Files property has been populated.
		/// This property is set to false whenever the Folder property is modified
		/// </summary>
		public bool FolderScanned
		{
			get{return this.folderScanned;}
		}


		private SortStrategy sortStrategy;
		/// <summary>
		/// The File Sorting Method to use
		/// </summary>
		public SortStrategy SortStrategy
		{
			get{return this.sortStrategy;}
			set{this.sortStrategy = value;}
		} 


		#endregion

		#region Constructors

		/// <summary>
		/// Creates an instance of the OsqlScrip Generator
		/// </summary>
		/// <param name="folder">The Full Path of the Folder to scan.</param>
		/// <param name="batchFileName">The Name of the batch script to be generated or appended</param>
		public OsqlScript(string folder,string batchFileName)
		{
			this.Folder  = folder;
			this.BatchFileName = batchFileName;
			//Default Values
			this.Server ="";
			this.Database ="";
			this.UserName ="";
			this.Password="";
			this.ReportFile="";
			this.UseIntegratedSecurity=false;
			this.SortStrategy = SortStrategy.DateCreated; //Default
		}

		#endregion

		#region Methods

		/// <summary>
		/// Generates the file
		/// </summary>
		public void Generate()
		{	
			//Populate the files collection
			if (!this.folderScanned) this.Scan();				
			
			int count = 0;			
			using(StreamWriter fs = File.Exists(this.BatchFileName)
					  ? new StreamWriter(this.BatchFileName) : File.CreateText(this.BatchFileName))
			{
				foreach(FileInfo file in this.Files)
				{
					count++;
					if (count == 1)
						fs.WriteLine(this.GenerateLine(file.Name,true));
					else
						fs.WriteLine(this.GenerateLine(file.Name,false));	
				}
			}			 
		}


		/// <summary>
		/// Generates a single line
		/// </summary>
		/// <param name="fileName">The Filename to use</param>
		/// <param name="overWriteReport">Indicates whether the Report file should be overwritten or appended to.
		/// Not valid if UseReportfile is false</param>
		/// <returns></returns>
		private string GenerateLine(string fileName,bool overWriteReport)
		{
			StringBuilder line = new StringBuilder();
			line.Append("osql");

			if (!this.useIntegratedSecurity)					
			{
				line.Append(" -U ");
				line.Append(this.UserName);
				line.Append(" -P ");
				line.Append(this.Password);
			}
			line.Append(" -S ");
			line.Append(this.Server);
			line.Append(" -d ");
			line.Append(this.Database);
			line.Append(" -n -i ");
			line.Append(fileName);
			if (this.UseReportFile)
			{
				if (overWriteReport)				
					line.Append(" > "); //Overwrite File
				else
					line.Append(" >> "); //Append to file
				line.Append(this.ReportFile);
			}
			return line.ToString();
		}
		

		/// <summary>
		/// Scans the folder and populates the Files collection
		/// </summary>
		private void Scan()
		{
			DirectoryInfo dir = new DirectoryInfo(this.folder);
			this.Files = dir.GetFiles("*.sql");
			this.Sort();
		}

		
		/// <summary>
		/// Sorts the order in which the file batch will be generated in the file.
		/// The sorting method is according to the SortStrategy property.
		/// </summary>
		private void Sort()
		{
			IComparer comparer = this.GetComparer();
			Array.Sort(this.files,comparer);
			return;
		}


		/// <summary>
		/// This Method returns the IComparer to use according to the SortStrategy property
		/// of the instance.
		/// </summary>
		/// <returns></returns>
		private IComparer GetComparer()
		{
			switch(this.SortStrategy)
			{
				case SortStrategy.Alphabetical:
					return new AlphabeticalComparer();					
				case SortStrategy.DateCreated:
					return new DateCreatedComparer();					
				case SortStrategy.DateModified:
					return new DateModifiedComparer(); 					
				case SortStrategy.FileNameDate:					
					return new FileNameDateComparer();		
				default:
					return null;
			}

		}


		#endregion		
	}
	public enum SortStrategy{Alphabetical,DateModified,DateCreated,FileNameDate};
	public class AlphabeticalComparer : IComparer
	{

		#region IComparer Members

				public int Compare(object x, object y)
				{
					if (!(x is FileInfo && y is FileInfo)) 
						throw new ArgumentException("The arguments must be of type FileInfo");
					else
					return ((FileInfo)x).Name.CompareTo(((FileInfo)y).Name);
				}

		#endregion
	}

	public class DateCreatedComparer : IComparer
	{

		#region IComparer Members

		public int Compare(object x, object y)
		{
			if (!(x is FileInfo && y is FileInfo)) 
				throw new ArgumentException("The arguments must be of type FileInfo");
			else
				return ((FileInfo)x).CreationTime.CompareTo(((FileInfo)y).CreationTime);
		}

		#endregion
	}
 
	public class DateModifiedComparer : IComparer
	{

		#region IComparer Members

		public int Compare(object x, object y)
		{
			if (!(x is FileInfo && y is FileInfo)) 
				throw new ArgumentException("The arguments must be of type FileInfo");
			else
				return ((FileInfo)x).LastWriteTime.CompareTo(((FileInfo)y).LastWriteTime);
		}

		#endregion
	}
 
	public class FileNameDateComparer : IComparer
	{

		#region IComparer Members

		public int Compare(object x, object y)
		{
			if (!(x is FileInfo && y is FileInfo)) 
				throw new ArgumentException("The arguments must be of type FileInfo");
			else
				try
				{					
					string fileX = Path.GetFileNameWithoutExtension(((FileInfo)x).Name);
					string fileY = Path.GetFileNameWithoutExtension(((FileInfo)y).Name);
					DateTime dateX = DateTime.Parse(fileX);
					DateTime dateY = DateTime.Parse(fileY);
					return dateX.CompareTo(dateY);
				}
				catch(FormatException)
				{
					//if the file name cannot be parsed for a date the 
					//filename are considered equal in sort order
					return 0; 
				}
		}


		#endregion
	}
 
}
